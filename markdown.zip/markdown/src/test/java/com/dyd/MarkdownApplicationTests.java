package com.dyd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Calendar;
import java.util.UUID;


@SpringBootTest
class MarkdownApplicationTests {

    @Test
    void contextLoads() {
        //获得SpringBoot当前项目的路径：System.getProperty("user.dir")
        String direct = System.getProperty("user.dir")+"/resources/upload";
        System.out.println(direct);

    }

}
