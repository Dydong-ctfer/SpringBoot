package com.dyd.controller;

import com.alibaba.fastjson.JSONObject;
import com.dyd.pojo.Article;
import com.dyd.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.UUID;

@Controller
public class MyController {

    @Autowired
    private ArticleService articleService;

    @PostMapping("/addArticle")
    public String addArticle(Article article){
        articleService.addArticle(article);
        return "editor/editormd";
    }

    @GetMapping("/toEditor")
    public String toEditor() {
        return "editor/editormd";
    }

    @GetMapping("/show")
    public String show(Model model) {
        Article article = articleService.getArticleById(4);
        model.addAttribute("article", article);
        return "editor/article";
    }

    @RequestMapping("/file/upload")
    @ResponseBody
    public JSONObject fileUpload(@RequestParam(value = "editormd-image-file", required = true) MultipartFile file, HttpServletRequest request) throws IOException {
        String path = System.getProperty("user.dir") + "/upload/";
        Calendar instance = Calendar.getInstance();
        String month = (instance.get(Calendar.MONTH) + 1) + "_month";
        path = path + month;
        File realPath = new File(path);
        if (!realPath.exists()) {
            realPath.mkdirs();
        }
        //上传文件地址
        System.out.println("上传文件保存地址：" + realPath);

        //解决文件名字问题：我们使用uuid;
        String filename = "pg-" + UUID.randomUUID().toString().replaceAll("-", "") + ".jpg";
        File newfile = new File(realPath, filename);
        //通过CommonsMultipartFile的方法直接写文件（注意这个时候）
        file.transferTo(newfile);

        //给editormd进行回调
        JSONObject res = new JSONObject();
        res.put("url", "/upload/" + month + "/" + filename);
        res.put("success", 1);
        res.put("message", "upload success!");
        System.out.println(res);
        return res;
    }
}
